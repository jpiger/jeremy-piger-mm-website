%Plot prior for linear regression with Normal-Gamma conjugate prior

clear;
clc;

%Load data

data_in=load('regression_data.txt');

Y=data_in(:,1);
X1=data_in(:,2);
X2=data_in(:,3);
X3=data_in(:,4);

[N,c] = size(Y);

X = [X1 X2 X3];

%Prior hyperparameters for Normal-Gamma

mu=[0 0 0]';
V=10.*eye(3);
m=1;
v=3;

%Plot the prior for B1, B2 and B3

%For B1

tvar = inv(m)*V;
tplot(mu(1), tvar(1,1), v, 'r');

%For B2

figure;  %Opens a new figure window

tvar = inv(m)*V;
tplot(mu(2), tvar(2,2), v, 'r');

%For B3

figure;

tvar = inv(m)*V;
tplot(mu(3), tvar(3,3), v, 'r');