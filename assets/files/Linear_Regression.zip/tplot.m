function r=tplot(a,b,c,col)
%gammaplot(a,b,col)
%plots a univariate t distribution with location parameter a, 
%scale parameter b, and degrees of freedom parameter c
%col is a text string which indicates the colour of the graph

x=[-10:.01:10];
const1 = (c^(c/2))*gamma((c+1)/2);
const2 = sqrt(b)*(pi^(1/2))*gamma(c/2);
for i=1:length(x)
    kernel = (((x(i)-a)/sqrt(b))^2 + c)^(-(c+1)/2);
    y(i)=(const1/const2)*kernel;
end

plot(x,y,col)