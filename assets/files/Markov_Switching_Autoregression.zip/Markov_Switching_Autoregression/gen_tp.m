function [tp] = gen_tp(s_in,alpha_1_0_in,alpha_2_0_in,alpha_1_1_in,alpha_2_1_in)

T = size(s_in,1);

% count switches

sw_00 = sum((s_in(1:T-1)==0).*(s_in(2:T)==0));
sw_01 = sum((s_in(1:T-1)==0).*(s_in(2:T)==1));
sw_11 = sum((s_in(1:T-1)==1).*(s_in(2:T)==1));
sw_10 = sum((s_in(1:T-1)==1).*(s_in(2:T)==0));

% generate transition probabilities

p00_gen = betarnd(alpha_1_0_in+sw_00,alpha_2_0_in+sw_01);
p11_gen = betarnd(alpha_1_1_in+sw_11,alpha_2_1_in+sw_10);

tp = [p00_gen;p11_gen];

end