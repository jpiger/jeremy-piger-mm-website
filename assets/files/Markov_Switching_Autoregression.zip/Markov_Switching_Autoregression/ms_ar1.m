%% Bayesian estimation of a Markov-Switching AR(1) Model

% Estimation is for simulated data, which is produced inside the
% program

% Estimation conducted using a Gibbs Sampler

%% Simulate Data Consistent with the Assumed GDP

clear;
clc;

T=200;

true_p00 = 0.95;
true_p11 = 0.70;
true_rho_0 = 0.9;
true_rho_1 = 0.5;
true_alpha_0 = 3;
true_alpha_1 = -1;
true_h_0 = 1;
true_h_1 = 4;

true_S = zeros(T,1);

for t = (2:T);
    u=rand(1,1);
    if true_S(t-1)==0;
        if u<=true_p00;
            true_S(t)=0;
        else
            true_S(t)=1;
        end
    else
        if u<=true_p11;
            true_S(t)=1;
        else
            true_S(t)=0;
        end
    end;
end;

Y = zeros(T,1);

for t = (2:T);
    Y(t) = (true_alpha_0 + true_rho_0*Y(t-1) + normrnd(0,sqrt(1/true_h_0)))*(1-true_S(t)) + (true_alpha_1 + true_rho_1*Y(t-1) + normrnd(0,sqrt(1/true_h_1)))*(true_S(t));
end;

%% Gibbs Sampler

% Prior parameters

% Hyperparameters for Normal distribution describing prior for conditional mean parameters 
%-> N(mu,V)
 
k = 4;  %Number of conditional mean parameters - 2 AR(1) coefficients and 2 intercepts
 
mu = zeros(k,1);
V = eye(k)*10;

% Hyperparameters for beta prior for transition probabilities

% for p00
alpha_1_0 = 9;
alpha_2_0 = 1;

% for p11
alpha_1_1 = 7;
alpha_2_1 = 3;

% Hyperparameters for Gamma distribution describing prior for error precisions, h_i = 1/sig2_i -> Gamma(m,v)
% In this paramterization of Gamma, E(h_i) = m and Var(h_i) = 2*(m^2)/v
 
m = 1;
v = 3;

% Design for the Gibbs Sampler
 
G0 = 1000;       % Number of burn-in draws
G = 10000;       % Number of post-convergence draws

total_draws = G0+G;  % Total number of draws

% Initial values for the Gibbs Sampler

p00_g = 0.5;
p11_g = 0.5;

p_g = [p00_g;p11_g];

alpha_g = [1;0];

rho_g = [0.9;0.9];

h_g = [1;1];

% Storage Spaces

pmm = zeros(2,G);
rhomm = zeros(2,G);
alphamm = zeros(2,G);
hmm = zeros(2,G);

smm=zeros(T-1,1);

for itr = (1:total_draws);
    
    % Start sampling 
    
    s_g = gen_s_ar1(Y,alpha_g,rho_g,h_g,p_g);
     
    h_vec_g = h_g(1).*(1-s_g) + h_g(2).*(s_g);    
    Yf = Y(2:T);
    X = [(1-s_g) s_g (Y(1:T-1).*(1-s_g)) (Y(1:T-1).*(s_g))];

    norm=0;
    while norm==0;
        beta_g = gen_beta_scale(Yf,X,h_vec_g,mu,V);
        if beta_g(1)>beta_g(2);
            norm=1;
        end;
    end;
    alpha_g = beta_g(1:2,1);
    rho_g = beta_g(3:4,1);
    
    Ystar = Yf((s_g==0));
    Xstar = X((s_g==0),:);
    h_0g = gen_h(Ystar,Xstar,beta_g,m,v);
 
    Ystar = Yf((s_g==1));
    Xstar = X((s_g==1),:);
    h_1g = gen_h(Ystar,Xstar,beta_g,m,v);
    
    h_g = [h_0g;h_1g];

    p_g = gen_tp(s_g,alpha_1_0,alpha_2_0,alpha_1_1,alpha_2_1);

    % Store results

    if itr>G0;
        alphamm(:,itr-G0) = alpha_g;
        rhomm(:,itr-G0) = rho_g;
        hmm(:,itr-G0) = h_g;
        pmm(:,itr-G0) = p_g;
        smm = smm + s_g;
    end;
    
    % Print out progress indicator
    if mod(itr/total_draws,0.10)==0;
        clc;
        disp('Estimation via Gibbs Sampler. Please Wait...');
        disp('Percent Complete');
        disp(((itr*100)/total_draws));
    end;
    
end;

%% Display Results

clc;

disp('Posterior median of intercept parameters')
disp(median(alphamm(:,1:G)'));

disp('Posterior median of AR(1) parameter')
disp(median(rhomm(:,1:G)'));

disp('Posterior median of disturbance variance')
disp(median(1./(hmm(:,1:G)')));

disp('Posterior median of transition probabilities')
disp(median(pmm(:,1:G)'));

figure(1);
plot(2:T, (smm./G))
title('Estimated Probability that S(t)=1')