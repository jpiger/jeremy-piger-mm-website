function S = gen_s_ar1(Y,alpha_in,rho_in,h_in,p_in)

    alpha_0 = alpha_in(1);
    alpha_1 = alpha_in(2);

    rho_0 = rho_in(1);
    rho_1 = rho_in(2);

    p00 = p_in(1);
    p11 = p_in(2);

    h_0 = h_in(1);
    h_1 = h_in(2);

    T = size(Y,1);
    
    Yf = Y(2:T);
    X = Y(1:T-1);
    
    T = size(Yf,1);

    flt_pr = zeros(2,T);
    dmnsion = 4;

    pr_tr = [[p00 (1-p11)];[(1-p00) p11]];

    sig_mat = [(1/h_0);(1/h_1);(1/h_0);(1/h_1)];

    % Initialize with steady state probabilties

    pr_trf = reshape(pr_tr,4,1);
    A = [[(eye(2)-pr_tr)];ones(1,2)];
    EN = [0;0;1];
    prob_T = (A'*A)\A'*EN;  % Pr[S_t=0]|PR[S_t=1],
                            % 2x1 steady-state probabilities
                            
    prob_ = reshape([prob_T prob_T]',4,1);

    % Begin filtering

    for itr = (1:T)
        
        f_cast1 = Yf(itr).*ones(dmnsion,1) - [(alpha_0 + rho_0*X(itr));(alpha_1 + rho_1*X(itr));(alpha_0 + rho_0*X(itr));(alpha_1 + rho_1*X(itr))];
    
        prob_dd = pr_trf.*prob_;

        pr_vl = (1./sqrt(2.*pi.*sig_mat)).*exp(-0.5*f_cast1.*f_cast1./sig_mat).*prob_dd;

        pr_val = sum(pr_vl);

        pro_ = pr_vl/pr_val;
       
        prob_T = pro_(1:dmnsion/2,1) + pro_(dmnsion/2+1:dmnsion,1);

        prob_ = reshape([prob_T prob_T]',4,1);

        flt_pr(:,itr) = prob_T;

    end;

    % Generate S

    S = zeros(T,1);
    S(T,1) = (rand < (flt_pr(2,T)/(flt_pr(1,T)+flt_pr(2,T))));

    for itr = (T-1:-1:1);
        
        if S(itr+1,1)==0;
            P0 = p00*flt_pr(1,itr);
            P1 = (1-p11)*flt_pr(2,itr);
        elseif S(itr+1,1)==1;
            P0 = (1-p00)*flt_pr(1,itr);
            P1 = p11*flt_pr(2,itr);
        end;
    
        S(itr) = (rand < (P1/(P0+P1))); 
    
    end;

end