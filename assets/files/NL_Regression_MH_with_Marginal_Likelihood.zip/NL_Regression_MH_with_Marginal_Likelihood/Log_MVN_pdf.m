function [log_pdf_val] = Log_MVN_pdf(theta_in, mu_in, chol_V_in)
    
    %Compute log of mvn pdf
    num_p = size(theta_in,1);
    
    opts.LT = true;
    Linvb = linsolve(chol_V_in, (theta_in-mu_in), opts);
         
    log_pdf_val = -0.5*num_p*log(2*pi) -0.5*log((prod(diag(chol_V_in)))^2) - 0.5*(Linvb'*Linvb); 
         
end

