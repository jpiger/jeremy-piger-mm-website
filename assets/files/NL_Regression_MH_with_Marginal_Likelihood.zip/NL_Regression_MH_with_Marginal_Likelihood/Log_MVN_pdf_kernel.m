function [log_pdf_val] = Log_MVN_pdf_kernel(theta_in, mu_in, chol_V_in)

    %Compute log of kernel of mvn pdf 

    opts.LT = true;
    Linvb = linsolve(chol_V_in, (theta_in-mu_in), opts);
         
    log_pdf_val = - 0.5*(Linvb'*Linvb);
    
end

