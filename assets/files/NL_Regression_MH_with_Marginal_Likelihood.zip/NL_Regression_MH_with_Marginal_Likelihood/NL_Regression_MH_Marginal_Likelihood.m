%% Bayesian estimation of a nonlinear regression model

% Includes estimation of marginal likelihood using approach of 
% Chib and Jeliaskov (1995) as well as Modified Harmonic Mean as in Geweke
% (1999).

%% Load Data

clear;
clc;

[num,txt,raw] = xlsread('nonlin_regression_data.xlsx','Sheet1','A2:C101');

Y = num(:,1);
X1 = num(:,2);
X2 = num(:,3);

[N] = size(Y,1);

%% Bayesian Estimation via Metropolis-Hastings Algorithm

% Prior Parameters

% Hyperparameters for Normal distribution describing prior for conditional mean parameters 
%-> N(mu,V)

k = 3;  %Number of conditional mean parameters

mu = zeros(k,1);
V = eye(k)*10;
chol_V = chol(V)';

% Hyperparameters for Gamma distribution describing prior for error precision, h = 1/sig2 -> Gamma(m,v)
% In this parameterization of Gamma, E(h) = m and Var(h) = 2*(m^2)/v

m = 1;
v = 3;

% Convert to the specification of Gamma used by Matlab

alpha=v/2;
beta = m/alpha;

% Number of Simulations from the MH Sampler

G0 = 10000;       %Number of burn-in draws
G = 100000;       %Number of post-convergence draws

total_draws = G0+G;  %Total number of draws

% Calibration of Proposal

cov_prop = eye(4);
num_param = k+1;
mu_prop = zeros(num_param,1);
tau = 0.001;  %Scaling for variance covariance matrix of shock to random walk proposal
R = tau.*cov_prop;  % Variance covariance matrix of shock to random walk proposal
chol_R = chol(R)';

% Initital Values for the MH Sampler

theta_g = ones(num_param,1);
log_lik_theta_g = Log_LF_NL_Regression(Y, X1, X2, theta_g);
log_prior_theta_g_kernel = Log_MVN_pdf_kernel(theta_g(2:k+1),mu,chol_V) + Log_Gamma_pdf_kernel(theta_g(1),alpha,beta);

% Storage Spaces

hmm = zeros(1,G);
gammamm = zeros(k,G);

accept=0;

% Start Sampling

itr=1;
while itr <= total_draws;  
    
    theta_star = theta_g + (mvnrnd(mu_prop,R))';

    log_lik_theta_star = Log_LF_NL_Regression(Y, X1, X2, theta_star);

    log_prior_theta_star_kernel = Log_MVN_pdf_kernel(theta_star(2:k+1),mu,chol_V) + Log_Gamma_pdf_kernel(theta_star(1),alpha,beta);

    % This acceptance probabilty does not include proposal, since they cancel
    % out when using a random walk proposal density

    log_acceptance_prob = (log_lik_theta_star+log_prior_theta_star_kernel)-(log_lik_theta_g+log_prior_theta_g_kernel);
    acceptance_prob = exp(log_acceptance_prob);
    acceptance_prob = min(acceptance_prob,1);

    u=unifrnd(0,1);

    if u<=acceptance_prob;
        theta_g = theta_star;
        log_lik_theta_g = log_lik_theta_star;
        log_prior_theta_g_kernel = log_prior_theta_star_kernel;
        accept = accept+1;
    end;
      
    if itr>G0;
        hmm(1,itr-G0) = theta_g(1);
        gammamm(:,itr-G0) = theta_g(2:num_param);
    end;

    % Print out progress indicator and acceptance rate
    if mod(itr/total_draws,0.10)==0;
        clc;
        disp('Estimation via Metropolis-Hastings Sampler. Please Wait...');
        disp('Percent Complete');
        disp(((itr*100)/total_draws));
        disp('Acceptance Rate: '); 
        disp(accept/itr);
    end;
    
    itr=itr+1;
end;

disp('Posterior median of gamma parameters')
disp(median(gammamm'));

disp('Posterior median of disturbance variance')
disp(median(1./(hmm')));

figure;

ksdensity(gammamm(1,:)')
title('Gamma 1')

figure;

ksdensity(gammamm(2,:))
title('Gamma 2')

figure;

ksdensity(gammamm(3,:))
title('Gamma 3')


%% Computation of marginal likelihood using approach of Chib and Jeliaskov (1995)

% Compute posterior medians at which to compute basic marginal likelihood identity

gamma_tilde = (median(gammamm'))';
h_tilde = (median(hmm'))';

theta_tilde = [h_tilde;gamma_tilde];

%Evaluate likelihood function and prior at theta_tilde
  
log_lik_theta_tilde = Log_LF_NL_Regression(Y, X1, X2, theta_tilde);
lik_val_theta_tilde = exp(log_lik_theta_tilde);

prior_val_theta_tilde = exp(Log_MVN_pdf(gamma_tilde,mu,chol_V))*exp(Log_Gamma_pdf(h_tilde,alpha,beta));

log_prior_theta_tilde_kernel = Log_MVN_pdf_kernel(theta_tilde(2:k+1),mu,chol_V) + Log_Gamma_pdf_kernel(theta_tilde(1),alpha,beta);

% Evaluate posterior at gamma_tilde and h_tilde

func1_save = 0;
func2_save = 0;

itr = 1;
while itr <= G;
    
    theta_g = [hmm(itr);gammamm(:,itr)];    
    
    log_lik_theta_g = Log_LF_NL_Regression(Y, X1, X2, theta_g);
    
    log_prior_theta_g_kernel = Log_MVN_pdf_kernel(theta_g(2:k+1),mu,chol_V) + Log_Gamma_pdf_kernel(theta_g(1),alpha,beta);

    % This acceptance probabilty does not include proposal, since they cancel
    % out when using a random walk proposal density
    
    log_acceptance_prob = (log_lik_theta_tilde+log_prior_theta_tilde_kernel)-(log_lik_theta_g+log_prior_theta_g_kernel);
    acceptance_prob = exp(log_acceptance_prob);
    acceptance_prob = min(acceptance_prob,1);

    propose_theta_tilde_g = exp(Log_MVN_pdf(abs(theta_tilde-theta_g),mu_prop,chol_R));
    
    func1_save = func1_save + (acceptance_prob*propose_theta_tilde_g);

    theta_star = theta_tilde + (mvnrnd(mu_prop,R))';
    
    log_lik_theta_star = Log_LF_NL_Regression(Y, X1, X2, theta_star);
    
    log_prior_theta_star_kernel = Log_MVN_pdf_kernel(theta_star(2:k+1),mu,chol_V) + Log_Gamma_pdf_kernel(theta_star(1),alpha,beta);

    % This acceptance probabilty does not include proposal, since they cancel
    % out when using a random walk proposal density

    log_acceptance_prob = (log_lik_theta_star+log_prior_theta_star_kernel)-(log_lik_theta_tilde+log_prior_theta_tilde_kernel);
    acceptance_prob = exp(log_acceptance_prob);
    acceptance_prob = min(acceptance_prob,1);
    
    func2_save = func2_save + acceptance_prob;
 
    if mod(itr/G,0.10)==0;
        clc;
        disp('Marginal Likelihood Calculating Using Chib and Jeliaskov(2001) Approach. Please Wait...');
        disp('Percent Complete');
        disp(((itr*100)/G));
    end;
     
    itr=itr+1;
end;

func1_save = func1_save/G;

func2_save = func2_save/G;

post_val_theta_tilde = func1_save/func2_save;

marg_lik_cj = (lik_val_theta_tilde*prior_val_theta_tilde) / post_val_theta_tilde;

%% Computation of marginal likelihood using Modified Harmonic Mean Estimator as in Geweke (1999)

inv_ml = 0;

num_param=k+1;

tau=0.99;
thresh = chi2inv(tau,k);

theta_hat = [mean(hmm);mean(gammamm')'];
v_hat = cov([hmm' gammamm']);
chol_v_hat = chol(v_hat)';
det_v_hat = (prod(diag(chol_v_hat)))^2;

itr=1;
while itr <= G;
    
    theta_g = [hmm(itr);gammamm(:,itr)];  
    
    opts.LT = true;
    Linvb = linsolve(chol_v_hat, (theta_g-theta_hat), opts);
    wstat = Linvb'*Linvb;
    
    if wstat<=thresh;
        log_f_theta = -(num_param/2)*log(2*pi) -0.5*log(det_v_hat) - 0.5*wstat - log(tau);
        log_prior_theta_g = Log_MVN_pdf(theta_g(2:num_param),mu,chol_V) + Log_Gamma_pdf(theta_g(1),alpha,beta);
        log_lik_theta_g = Log_LF_NL_Regression(Y, X1, X2, theta_g);
        log_ratio = log_f_theta - (log_prior_theta_g + log_lik_theta_g);
        ratio = exp(log_ratio);
    else
        ratio=0;
    end

    inv_ml = inv_ml+ratio;

    if mod(itr/G,0.10)==0;
        clc;
        disp('Marginal Likelihood Calculating Using Modified Harmonic Mean Estimator. Please Wait...');
        disp('Percent Complete');
        disp(((itr*100)/G));
    end;
    
    itr=itr+1;
end;

inv_ml = inv_ml/G;

marg_lik_mhme = 1/inv_ml;

%% Display Results

clc;
disp('Marginal Likelihood and Log Marginal Likelihood Calculated using Chib and Jeliaskov (2001) approach: ');
disp(marg_lik_cj);
disp(log(marg_lik_cj));

disp('Marginal Likelihood and Log Marginal Likelihood Calculated using Modified Harmonic Mean Estimator as in Geweke (1999): ');
disp(marg_lik_mhme);
disp(log(marg_lik_mhme));

disp('Ratio of Marginal Likelihood from Chib and Jeliaskov (2001) to Geweke (1999): ');
disp(marg_lik_cj/marg_lik_mhme);