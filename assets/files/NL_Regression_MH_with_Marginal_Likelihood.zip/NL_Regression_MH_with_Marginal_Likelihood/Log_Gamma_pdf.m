function [log_pdf_val] = Log_Gamma_pdf(h_in, alpha_in, beta_in)
    
    %Compute log of gamma pdf 
    log_pdf_val = -alpha_in*log(beta_in) - gammaln(alpha_in) + (alpha_in-1)*log(h_in) - (h_in/beta_in); 
         
end

