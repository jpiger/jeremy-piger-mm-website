function [log_pdf_val] = Log_Gamma_pdf_kernel(h_in, alpha_in, beta_in)
    
    %Compute log of kernel of gamma pdf 
    log_pdf_val = (alpha_in-1)*log(h_in) - (h_in/beta_in); 
         
end

