%% Bayesian estimation of a linear regression model via the Gibbs Sampler

% Uses data from Hamermesh and Parker (2005, Economics of Education Review)

% Program includes examples of three MCMC diagnostics: the 
% autocorrelation function, trace plots, and running mean plots. 

%% Load Data

clear;
clc;

[num,txt,raw] = xlsread('TeachingRatings.xls',1);

minority = num(:,1);
age = num(:,2);
female = num(:,3);
one_credit = num(:,4);
beauty = num(:,5);
course_eval = num(:,6);
intro = num(:,7);
nnenglish = num(:,8);

Y = course_eval;

[N,c]=size(Y);

X = [ones(N,1) beauty female minority nnenglish intro one_credit];

%% Gibbs Sampler 

% Prior Parameters

% hyperparameters for Normal distribution describing prior for conditional mean parameters 
%-> N(mu,V)

[N,k] = size(X);  %Sample size (N) and number of conditional mean parameters (k)

mu = zeros(k,1);
V = eye(k)*10;
inv_V = inv(V);
chol_V = chol(V);

% hyperparameters for Gamma distribution describing prior for error precision, h = 1/sig2 -> Gamma(m,v)
% In this paramterization of Gamma, E(h) = m and Var(h) = 2*(m^2)/v

m = 1;
v = 3;

% Convert to the specification of Gamma used by Matlab

a = v/2;
b = m/a;

% Design for the Gibbs Sampler

G0 = 10000;       % Number of burn-in draws
G = 100000;       % Number of post-convergence draws

total_draws = G0+G;  % Total number of draws

% Initial values for the Gibbs Sampler

beta_g = zeros(k,1);

% Storage Spaces

% These will hold the pre-convergence draws

beta0mm = zeros(k,G0);
h0mm = zeros(1,G0);

% These will hold the post-convergence draws

betamm = zeros(k,G);
hmm = zeros(1,G);

itr=1;
while itr <= total_draws;  
    
    % Start sampling
    
    h_g=gen_h(Y,X,beta_g,N,m,v);
    
    beta_g=gen_beta(Y,X,h_g,mu,V);
    
    % Store Results
    
    if itr>G0;
        betamm(:,itr-G0) = beta_g;
        hmm(itr-G0) = h_g;
    else
        beta0mm(:,itr) = beta_g;
        h0mm(:,itr) = h_g;
    end
    
    % Print out progress indicator
    if mod(itr/total_draws,0.10)==0;
        clc;
        disp('Estimation via Gibbs Sampling. Please Wait...');
        disp('Percent Complete');
        disp(((itr*100)/total_draws));
    end;
    
    itr=itr+1;
end;

%% Display Estimation Results
disp('Posterior median of intercept and slope parameters')
disp(median(betamm')')

disp('Posterior median of disturbance variance')
disp(median(1./(hmm'))')

disp('OLS estimates of intercept and slope parameters')
disp(inv(X'*X)*X'*Y)

%% Compute and Report MCMC Diagnostics

% Trace plot for all parameters

num_period = 200;

figure(1);
subplot(2,2,1);
plot(1:num_period, beta0mm(1,1:num_period));
title('Trace plot for intercept');

subplot(2,2,2);
plot(1:num_period, beta0mm(2:k,1:num_period));
title('Trace plot for all slope coefficients');

subplot(2,2,3.5);
plot(1:num_period, h0mm(1,1:num_period));
title('Trace plot for precision');

% Running mean plot

theta0mm = [beta0mm;h0mm];

running_mean_vec = zeros(k+1,G0);
running_mean_vec(:,1) = theta0mm(:,1);

itr=2;
while itr <= G0;
    
    mean_vec = mean(theta0mm(:,1:itr)');
    
    running_mean_vec(:,itr) = mean_vec';
    
    itr=itr+1;

end;

num_period = 200;

figure(2)
subplot(2,2,1)
plot(1:num_period, running_mean_vec(1,1:num_period))
title('Running mean plot for intercept')

subplot(2,2,2);
plot(1:num_period, running_mean_vec(2:k,1:num_period))
title('Running mean plot for slope coefficients')

subplot(2,2,3.5);
plot(1:num_period, running_mean_vec(k+1,1:num_period))
title('Running mean plot for precision')


%Autocorrelation Function for part of pre-convergence period

num_ac = 200;
acf_vec = zeros(num_ac,1);

itr=1;
while itr <= num_ac;
    
    beta2fmm = beta0mm(2,1+itr:G0);
    beta2lmm = beta0mm(2,1:G0-itr);
    
    q=cov(beta2fmm',beta2lmm');
    acf=corrcov(q);
    
    acf_vec(itr) = acf(1,2);
    
    itr=itr+1;

end;

figure(3)
bar(1:num_ac, acf_vec)
title('Autocorrelation function (pre-convergence) for coefficient on Beauty')

% Effective sample size for coefficient on beauty

num_ac = 200;
acf_sum = 0;

itr=1;
while itr <= num_ac;
    
    beta2fmm = betamm(2,1+itr:G);
    beta2lmm = betamm(2,1:G-itr);
    
    q=cov(beta2fmm',beta2lmm');
    acf=corrcov(q);
    
    acf_sum = acf_sum + acf(1,2);
    
    itr=itr+1;

end;

ESS = G/(1+2*acf_sum);

disp('The Effective Sample Size for the coefficient on beauty is:');
disp(round(ESS));