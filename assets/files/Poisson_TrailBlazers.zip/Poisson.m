%Bayesian estimation and forecasting of Poisson model for points scored by 
%2014-2015 Portland Trail Blazers

clear;
clc;

%Input Data

Y=xlsread('TrailBlazerPoints_14_15.xlsx','Sheet1','E2:E64');

[N,c]=size(Y);

%Plot the prior

alpha_p=10;
beta_p=10;
%These parameter values give a mean of 100

gammaplot(alpha_p, beta_p, 'r');

%Plot the posterior

s=sum(Y);
alpha_bar = alpha_p+s;
beta_bar = inv(N+inv(beta_p));

figure;

gammaplot(alpha_bar, beta_bar, 'b');

%Posterior summary statistics

disp('The Posterior Mean is:');
disp(alpha_bar*beta_bar);

disp('The Posterior variance is:');
disp(alpha_bar*(beta_bar^2));

%Posterior Predictive Distribution

theta_nb = (beta_bar/(1+beta_bar));
r_nb = alpha_bar;

nbin_ind = (0:200)';

ln_nbin_dens = gammaln(nbin_ind+r_nb) - gammaln(nbin_ind+1) - gammaln(r_nb) + nbin_ind*log(theta_nb) + r_nb*log(1-theta_nb);

nbin_dens = exp(ln_nbin_dens);

disp('Mean of posterior predictive density:');
disp((r_nb*theta_nb)/(1-theta_nb));

disp('Mode of posterior predictive density:');
[mode_nb,I] = max(nbin_dens);
disp(I-1);

figure;

plot(nbin_ind(71:141),nbin_dens(71:141));

disp('Probability that the Trail Blazers score more than 100 points');

disp(sum(nbin_dens(101:201)));

disp('Probability that the Trail Blazers score between 90 and 110 points');

disp(sum(nbin_dens(91:111)));