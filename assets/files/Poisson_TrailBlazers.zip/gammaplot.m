function r=gammaplot(a,b,col)
%gammaplot(a,b,col)
%plots a GAMMA distribution with parameters a and b > 0
%col is a text string which indicates the colour of the graph

x=[0:.01:200];
%const1=(b^a)*gamma(a);
logconst1=a*log(b) + gammaln(a);
%Use this when the vector of data gets
%long - prevents numerical overflows in gamma function.

for i=1:length(x)
    
   %y(i) = (1/const1)*(x(i)^(a-1))*exp(-x(i)/b);  
   
   y(i) = (a-1)*log(x(i)) - (x(i)/b) - logconst1;
   y(i) = exp(y(i));
      
end

plot(x,y,col)