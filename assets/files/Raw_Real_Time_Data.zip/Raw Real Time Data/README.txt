Raw real-time data files for �Identifying Business Cycle Turning Points in Real Time with Vector Quantization� by Andrea Giusto and Jeremy Piger, International Journal of Forecasting, 2017. These data files are updated versions of those collected for "A Comparison of the Real-Time Performance of Business Cycle Dating Methods" by Marcelle Chauvet and Jeremy Piger, Journal of Business and Economic Statistics, 2008. Please cite accordingly. 

File Descriptions:

emp_rt.xls:  U.S. Total Nonfarm Payroll Employment for vintages from November 5, 1976 to August 2, 2013. Source: Federal Reserve Bank of St. Louis ALFRED (https://alfred.stlouisfed.org).

ip_rt.xls: U.S. Industrial Production Index for vintages from November 15, 1976 to August 15, 2013. Source: Federal Reserve Bank of St. Louis ALFRED (https://alfred.stlouisfed.org).

real_mts_rt.xls: U.S. Real Manufacturing and Trade Industries Sales for vintages from December 2, 1976 to August 30, 2013. Sources: Government publications including "Business Conditions Digest", "Survey of Current Business", "Business Cycle Indicators", "Business Statistics", and "Survey of Current Business." Later vintages were obtained from the Bureau of Economic Analysis website (www.bea.gov). For a small number of individual vintages, there were gaps in the data available. These were filled in using the procedure described in Appendix A.2 of Chauvet and Piger (2008).  

real_pi_less_tp_rt.xls: U.S. Real Personal Income Excluding Current Transfer Receipts for vintages from November 17, 1976 to October 30, 1995. Sources: "Business Conditions Digest" and "Survey of Current Business." Data for U.S. Real Personal Income Excluding Current Transfer Receipts for vintages after October 30, 1995 was formed by subtracting nominal transfer payments from nominal personal income, and dividing by the ratio of nominal to real disposable personal income. 

pi_rt.xls: U.S. Nominal Personal Income for vintages from January 23, 1996 to August 30, 2013. Source: Federal Reserve Bank of St. Louis ALFRED (https://alfred.stlouisfed.org).

tp_rt.xls: U.S. Nominal Current Transfer Receipts for vintages from January 23, 1996 to August 30, 2013. Sources: "Economic Indicators", "Business Statistics", and the "Survey of Current Business." Later vintages were obtained from the Bureau of Economic Analysis website (www.bea.gov).  

dpi_rt.xls: U.S. Nominal Disposable Personal Income for vintages from January 23, 1996 to August 30, 2013. Source: Federal Reserve Bank of St. Louis ALFRED (https://alfred.stlouisfed.org).

real_dpi_rt.xls: U.S. Real Disposable Personal Income for vintages from January 23, 1996 to August 30, 2013. Source: Federal Reserve Bank of St. Louis ALFRED (https://alfred.stlouisfed.org).