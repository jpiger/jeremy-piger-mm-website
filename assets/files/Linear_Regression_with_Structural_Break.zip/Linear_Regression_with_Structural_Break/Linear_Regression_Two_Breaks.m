%% Bayesian estimation of a linear regression model with two structural breaks

% Estimation is for simulated data, which is produced inside the
% program

% Estimation conducted using a Gibbs Sampler
% Marginal Likelihood computed as in Chib (1995)

%% Simulate Data Consistent with the Assumed GDP
clear;
clc;

T=200;

true_tau = [50;120];

[D_0t, D_1t, D_2t] = create_dummy_two_break(true_tau(1),true_tau(2),T);

X_ind_var = normrnd(0,sqrt(3),T,1);

true_X = [ones(T,1).*D_0t, ones(T,1).*D_1t, ones(T,1).*D_2t, X_ind_var.*D_0t, X_ind_var.*D_1t, X_ind_var.*D_2t];
true_beta = [2;2;2;2;3;4];

true_h = [1;1;1];
true_sig = 1./true_h;

true_sigma = diag(true_sig(1)*D_0t + true_sig(2)*D_1t + true_sig(3)*D_2t);

u = mvnrnd(zeros(T,1),true_sigma)';

Y = true_X*true_beta + u;

%% Gibbs Sampler

% Prior parameters
 
% Hyperparameters for Normal distribution describing prior for conditional mean parameters 
%-> N(mu,V)
 
k = 6;  %Number of conditional mean parameters - 3 slope coefficients and 3 intercepts
 
mu = zeros(k,1);
V = eye(k)*10;
 
% Hyperparameters for Gamma distribution describing prior for error precisions, h_i = 1/sig2_i -> Gamma(m,v)
% In this paramterization of Gamma, E(h_i) = m and Var(h_i) = 2*(m^2)/v
 
m = 1;
v = 3;
 
% Prior for tau is uniform over all possible placements of tau. This is
% implicit in the Gibbs Sampler below. 

% Matrix holding possible locations of break dates
tau_mat = nchoosek((2:1:T),2);

% Design for the Gibbs Sampler
 
G0 = 1000;       % Number of burn-in draws
G = 10000;       % Number of post-convergence draws
 
total_draws = G0+G;  % Total number of draws
 
% Initial values for the Gibbs Sampler

% Initial values are set by setting breaks to be equally spread through
% sample, and then computing OLS quantities for other parameters. 

tau_g = [floor(T/3);floor(2*T/3)];

[D_0g, D_1g, D_2g] = create_dummy_two_break(tau_g(1),tau_g(2),T);
 
X = [ones(T,1).*D_0g, ones(T,1).*D_1g, ones(T,1).*D_2g, X_ind_var.*D_0g, X_ind_var.*D_1g, X_ind_var.*D_2g];

beta_g = (X'*X)\(X'*Y);
e = Y-X*beta_g;

estar = e((D_0g==1));
sig2_g1 = (estar'*estar)/(tau_g(1)-1);
 
estar = e((D_1g==1));
sig2_g2 = (estar'*estar)/(tau_g(2)-tau_g(1));

estar = e((D_2g==1));
sig2_g3 = (estar'*estar)/(T-(tau_g(2)-1));

h_g = [(1/sig2_g1);(1/sig2_g2);(1/sig2_g3)];

% Storage Spaces

betamm = zeros(k,G);
hmm = zeros(3,G);
taumm = zeros(2,G);

for itr = (1:total_draws);
    
    % Start sampling 
    
    % Sample beta from p(beta | h, tau, Y, X)

    h_g_vec = h_g(1)*D_0g + h_g(2)*D_1g + h_g(3)*D_2g;
    
    beta_g = gen_beta_scale(Y,X,h_g_vec,mu,V);
    
    % Sample h from p(h | beta, tau, Y, X)

    Ystar = Y((D_0g==1));
    Xstar = X((D_0g==1),:);
    h_g1 = gen_h(Ystar,Xstar,beta_g,m,v);
 
    Ystar = Y((D_1g==1));
    Xstar = X((D_1g==1),:);
    h_g2 = gen_h(Ystar,Xstar,beta_g,m,v);

    Ystar = Y((D_2g==1));
    Xstar = X((D_2g==1),:);
    h_g3 = gen_h(Ystar,Xstar,beta_g,m,v);

    h_g = [h_g1;h_g2;h_g3];

    % Sample tau from p(tau | beta, h, Y, X)

    tau_g = gen_tau(Y,X_ind_var,beta_g,h_g,tau_mat,T);
    
    [D_0g, D_1g, D_2g] = create_dummy_two_break(tau_g(1),tau_g(2),T);
 
    X = [ones(T,1).*D_0g, ones(T,1).*D_1g, ones(T,1).*D_2g, X_ind_var.*D_0g, X_ind_var.*D_1g, X_ind_var.*D_2g];

    % Store results

    if itr>G0;
        betamm(:,itr-G0) = beta_g;
        hmm(:,itr-G0) = h_g;
        taumm(:,itr-G0) = tau_g;
    end;

    % Print out progress indicator
    if mod(itr/total_draws,0.10)==0;
        clc;
        disp('Estimation via Gibbs Sampler. Please Wait...');
        disp('Percent Complete');
        disp(((itr*100)/total_draws));
    end;
    
end;

    
%% Marginal Likelihood calculation using approach of Chib (1995)

 % Print out wait message
 
 clc;   
 disp('Estimation of Marginal Likelihood. Please Wait...');
   
% Compute posterior medians at which to compute basic marginal likelihood identity

beta_tilde = median(betamm(:,1:G)')';
h_tilde = median(hmm(:,1:G)')';
tau_tilde = mode(taumm(:,1:G)')';

% Compute the index of the row in tau_mat that matches tau_tilde
loc_tau_tilde = find(ismember(tau_mat,tau_tilde','rows'));

[D_0_tilde, D_1_tilde, D_2_tilde] = create_dummy_two_break(tau_tilde(1),tau_tilde(2),T);

X = [ones(T,1).*D_0_tilde, ones(T,1).*D_1_tilde, ones(T,1).*D_2_tilde, X_ind_var.*D_0_tilde, X_ind_var.*D_1_tilde, X_ind_var.*D_2_tilde];
 
h_tilde_vec = h_tilde(1)*D_0_tilde + h_tilde(2)*D_1_tilde + h_tilde(3)*D_2_tilde;
 
%Evaluate likelihood function and prior at beta_tilde, h_tilde, and tau_tilde

Omega_inv = diag(h_tilde_vec);
lik_val = ((2*pi)^(-T/2))*(prod(h_tilde_vec))^(0.5)*exp(-0.5*(Y-X*beta_tilde)'*Omega_inv*(Y-X*beta_tilde));
log_lik_val = log(lik_val);

log_prior_val_beta = Log_MVN_pdf(beta_tilde,mu,chol(V));
 
a = v/2;
b = m/a;

log_prior_val_h = Log_Gamma_pdf(h_tilde(1),a,b) + Log_Gamma_pdf(h_tilde(2),a,b) + Log_Gamma_pdf(h_tilde(3),a,b);

log_prior_val_tau = log(1/(size(tau_mat,1)));

log_prior_val = log_prior_val_beta + log_prior_val_h + log_prior_val_tau;
 
% Evaluate posterior at beta_tilde, h_tilde and tau_tilde

% Compute p(beta_tilde | h_tilde, tau_tilde, Y) analytically
 
Sigma_inv = diag(h_tilde_vec);

Vbar = X'*Sigma_inv*X + inv(V);
     
mubar = Vbar\((X'*Sigma_inv*Y))+ (V\mu);
     
log_post_val_beta = Log_MVN_pdf(beta_tilde,mubar,chol(inv(Vbar)));
  
% Estimate p(h_tilde | tau_tilde,Y) via Monte Carlo integration
% Utilizes a reduced Gibbs run

% Initial values for the Gibbs Sampler

% Initial values are set by computing OLS quantities for parameters conditional 
% on posterior median of break dates. 
 
X = [ones(T,1).*D_0_tilde, ones(T,1).*D_1_tilde, ones(T,1).*D_2_tilde, X_ind_var.*D_0_tilde, X_ind_var.*D_1g, X_ind_var.*D_2g];

beta_g = (X'*X)\(X'*Y);
e = Y-X*beta_g;

estar = e((D_0g==1));
sig2_g1 = (estar'*estar)/(tau_g(1)-1);
 
estar = e((D_1g==1));
sig2_g2 = (estar'*estar)/(tau_g(2)-tau_g(1));

estar = e((D_2g==1));
sig2_g3 = (estar'*estar)/(T-(tau_g(2)-1));

h_g = [(1/sig2_g1);(1/sig2_g1);(1/sig2_g3)];

% Storage Spaces

post_val_h=0;

for itr = (1:total_draws);
    
    h_g_vec = h_g(1)*D_0_tilde + h_g(2)*D_1_tilde + h_g(3)*D_2_tilde;
    
    beta_g = gen_beta_scale(Y,X,h_g_vec,mu,V);
    
    Ystar = Y((D_0_tilde==1));
    Xstar = X((D_0_tilde==1),:);
    
    resid = Ystar - Xstar*beta_g;
    
    vbar = size(resid,1) + v;
    mbar = vbar/(resid'*resid + v/m);

    abar = vbar/2;
    bbar = mbar/abar;

    post_val_h1 = exp(Log_Gamma_pdf(h_tilde(1),abar,bbar));    

    h_g1 = gen_h(Ystar,Xstar,beta_g,m,v);
     
    Ystar = Y((D_1_tilde==1));
    Xstar = X((D_1_tilde==1),:);

    resid = Ystar - Xstar*beta_g;
    
    vbar = size(resid,1) + v;
    mbar = vbar/(resid'*resid + v/m);

    abar = vbar/2;
    bbar = mbar/abar;

    post_val_h2 = exp(Log_Gamma_pdf(h_tilde(2),abar,bbar));
    
    h_g2 = gen_h(Ystar,Xstar,beta_g,m,v);
     
    Ystar = Y((D_2_tilde==1));
    Xstar = X((D_2_tilde==1),:);

    resid = Ystar - Xstar*beta_g;
    
    vbar = size(resid,1) + v;
    mbar = vbar/(resid'*resid + v/m);

    abar = vbar/2;
    bbar = mbar/abar;

    post_val_h3 = exp(Log_Gamma_pdf(h_tilde(1),abar,bbar));
        
    h_g3 = gen_h(Ystar,Xstar,beta_g,m,v);
     
    h_g = [h_g1;h_g2;h_g3];
     
    post_val_h = post_val_h + (post_val_h1*post_val_h2*post_val_h3);
     
end;
 
log_post_val_h = log(post_val_h/G);
  
% Estimate p(tau_tilde | Y via Monte Carlo integration
 
post_val_tau = 0;

for itr = (1:G);
    
    beta_g = betamm(:,itr)';
    h_g = hmm(:,itr)';

    post_val_tau_t = Log_two_break_date_pdf(Y,X_ind_var,beta_g,h_g,tau_mat,T,loc_tau_tilde);

    post_val_tau = post_val_tau + post_val_tau_t;
 
end;
  
log_post_val_tau = log(post_val_tau/G);
  
log_post_val = log_post_val_beta + log_post_val_h + log_post_val_tau;
 
log_marg_lik_chib = (log_lik_val + log_prior_val) - log_post_val;
 
%% Display Results

clc;

disp('Posterior median of intercept and slope parameters')
disp(median(betamm(:,1:G)'));

disp('Posterior median of disturbance variance')
disp(median(1./(hmm(:,1:G)')));

disp('Posterior mode of break dates')
disp(mode(taumm(:,1:G)'));

figure;

hist(taumm(1,1:G)')
title('Posterior Density of First Break Dates')

figure;

hist(taumm(2,1:G)')
title('Posterior Density of Second Break Dates')

disp('Log of Marginal Likelihood');
disp(log_marg_lik_chib);