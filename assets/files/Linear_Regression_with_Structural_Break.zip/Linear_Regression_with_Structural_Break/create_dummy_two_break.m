function [D_0, D_1, D_2] = create_dummy_two_break(tau1, tau2, T_in)

D_0 = [ones(tau1-1,1);zeros(T_in-(tau1-1),1)];
D_1 = [zeros(tau1-1,1);ones(tau2-1-(tau1-1),1);zeros(T_in-(tau2-1),1)];
D_2 = [zeros(tau2-1,1);ones(T_in-(tau2-1),1)];
     
end

