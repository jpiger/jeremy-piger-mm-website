function dens = Log_two_break_date_pdf(Y, X_ind_var, beta, h, tau_mat, T, loc_tau_in)

e1 = ((Y - beta(1) - X_ind_var*beta(4)).*sqrt(h(1))).^2;
e2 = ((Y - beta(2) - X_ind_var*beta(5)).*sqrt(h(2))).^2;
e3 = ((Y - beta(3) - X_ind_var*beta(6)).*sqrt(h(3))).^2;

e1 = cumsum(e1);
e2 = cumsum(e2);
e3 = cumsum(e3);

ssr = e1(tau_mat(:,1)-1) + (e2(tau_mat(:,2)-1) - e2(tau_mat(:,1)-1)) + (e3(T) - e3(tau_mat(:,2)-1));

lik_vec = (sqrt(h(1)).^(tau_mat(:,1)-1)).*(sqrt(h(2)).^(tau_mat(:,2)-tau_mat(:,1))).*(sqrt(h(3)).^(T-(tau_mat(:,2)-1))).*exp(-0.5.*ssr);
 
prob_vec = lik_vec(:,1)/sum(lik_vec(:,1));

dens = prob_vec(loc_tau_in);

end