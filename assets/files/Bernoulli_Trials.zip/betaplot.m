function r=betaplot(a,b,col)
%betaplot(a,b,col)
%plots a BETA distribution with parameters a and b > 0
%col is a text string which indicates the colour of the graph

x=[0:.01:1];
const1=beta(a,b);
for i=1:length(x)
   y(i)=1/const1*x(i)^(a-1)*(1-x(i))^(b-1);
end

plot(x,y,col)