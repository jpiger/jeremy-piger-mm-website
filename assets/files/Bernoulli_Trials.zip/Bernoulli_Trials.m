%Bayesian estimation of success probability of Bernoulli trials

clear;
clc;

%Input Data

Y=[1 1 0 0 0 1 1 0 0 0]';

N=length(Y);

%Plot the prior

alpha1=1;
alpha2=1;
betaplot(alpha1, alpha2, 'r');

%Plot the posterior

s=sum(Y);

hold on;

betaplot(alpha1+s, alpha2+N-s, 'b');

hold off;

%Compute summary statistics about the posterior via simulation. Some of
%these could be computed analytically, but we will use simulation since
%this is what we usually have to do

beta_gen = betarnd(alpha1+s,alpha2+N-s,1000000,1);

disp('The Posterior Mean is:');
disp(mean(beta_gen));

disp('The Posterior Median is:');
disp(prctile(beta_gen,50));

%Specify coverage parameter for central posterior interval

cover = 95;

% Compute Central Posterior Interval
cent_int = prctile(beta_gen,[((100-cover)/2),100-((100-cover)/2)]);

disp('The Central Posterior Interval is: ');
disp(cent_int');