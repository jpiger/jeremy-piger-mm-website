function [y_p] = gen_ystar(NBER, X, beta)

[T]=size(NBER,1);

y_mean=X*beta;

y_p = normrnd(0,1,T,1) + y_mean;

y_p_indic = (y_p > 0);

correct_indic = (NBER==y_p_indic);

y_p = y_p.*correct_indic;

incorrect_indic = (NBER~=y_p_indic);

while sum(incorrect_indic)~=0
    
y_mean_temp = y_mean(incorrect_indic);

y_p_temp = normrnd(0,1,sum(incorrect_indic),1) + y_mean_temp;

y_p(incorrect_indic) = y_p_temp;

y_p_indic = (y_p > 0);

correct_indic = (NBER==y_p_indic);

y_p = y_p.*correct_indic;

incorrect_indic = (NBER~=y_p_indic);

end;

end