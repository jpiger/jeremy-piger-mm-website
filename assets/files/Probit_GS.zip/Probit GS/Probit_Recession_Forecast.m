%Bayesian estimation of a probit recession forecasting model
%Estimation conducted using Gibbs Sampler

clear;
clc;

tic;

%Input Raw Data. Data is monthly, from January 1960 to February 2014

[num,txt,raw] = xlsread('Recession_Forecast_Data.xlsx',1);

Date_vec_raw = num(:,1);
NBER_raw = num(:,2);
FFR_raw = num(:,3);
SP500_raw = num(:,4);
tenyr_raw = num(:,5);
threemo_raw = num(:,6);

[T_all]=size(Date_vec_raw,1);

% Use the following T to have end of sample be 2007:1
% T_all = 565;

% Form Three Month Equity Returns and the Yield Spread
Date_vec_all = Date_vec_raw(4:T_all);
NBER_all = NBER_raw(4:T_all);
FFR_all = FFR_raw(4:T_all);
SP500_return_all = ((SP500_raw(4:T_all)./SP500_raw(1:T_all-3)-1))*100;
Spread_all = tenyr_raw-threemo_raw;
Spread_all = Spread_all(4:T_all);

T_all = size(Date_vec_all,1);

% Construct data matrices for estimation of 12 month ahead forecasting
% model

Date_vec = Date_vec_all(13:T_all);

NBER = NBER_all(13:T_all); % NBER Recession Indicator. This is the left hand side variable.

FFR = FFR_all(1:T_all-12); % Federal Funds Rate
SP500_return = SP500_return_all(1:T_all-12); % S&P 500 Return
Spread = Spread_all(1:T_all-12); % Term Spread

X = [ones(T_all-12,1) FFR SP500_return Spread];

[T,k] = size(X);

% Construct end-of-sample data matrices for forecasting 12 months ahead

FFR_eos = FFR_all(T_all); % Federal Funds Rate
SP500_return_eos = SP500_return_all(T_all); % S&P 500 Return
Spread_eos = Spread_all(T_all); % Term Spread

X_eos = [1 FFR_eos SP500_return_eos Spread_eos];

%=================  PRIOR PARAMETERS ====================

% hyperparameters for Normal distribution describing prior for beta 
%-> N(mu,V)

mu = zeros(k,1);
V = eye(k)*10;


%===== DESIGN  for THE GIBBS SAMPLER ===========

G0 = 1000;       %NUMBER OF BURN IN DRAWS
G = 2000;       %NUMBER OF POST CONVERGENCE DRAWS

total_draws = G0+G;  %TOTAL NUMBER OF DRAWS


%========INITIAL VALUES FOR THE GIBBS SAMPLER ===========

beta_g = zeros(k,1);


%===== STORAGE SPACES===========================

beta_mat = zeros(k,G);

prob_vec = zeros(T,1); %Storage space to hold in-sample Recession probabilities

forecast_vec = zeros(1,G); %Storage space to hold out-of-sample Recession probabilities

itr=1;
while itr <= total_draws;  

if rem(itr,100)==0;
    disp('Current Iteration is:');
    disp(itr);
end;


%=================START SAMPLING================

ystar_g = gen_ystar(NBER,X,beta_g);

beta_g = gen_beta(ystar_g,X,1,mu,V);


%=========STORE RESULTS==========================

if itr>G0;
     
prob_vec_temp = normcdf(X*beta_g,0,1);
prob_vec = prob_vec + prob_vec_temp;

beta_mat(:,itr-G0) = beta_g;

forecast_vec_temp = normcdf(X_eos*beta_g,0,1);
forecast_vec(1,itr-G0) = forecast_vec_temp;

end;

itr=itr+1;
end;

beta_mat=beta_mat';

figure;

ksdensity(beta_mat(:,2));

title('Posterior Density of Parameter on Federal Funds Rate');

figure;

ksdensity(beta_mat(:,3));

title('Posterior Distribution of Parameter on S&P 500 Return');

figure;

ksdensity(beta_mat(:,4));

title('Posterior Distribution of Parameter on Term Spread');

disp('Posterior mean of intercept and slope parameters')
disp(mean(beta_mat))
 
prob_vec = prob_vec/G;

figure;

plot(prob_vec);

title('Posterior Mean of In-Sample Recession Forecast Probability');
 
figure; 

ksdensity(forecast_vec');
title('Posterior Distribution of 12 month ahead forecast');

toc;