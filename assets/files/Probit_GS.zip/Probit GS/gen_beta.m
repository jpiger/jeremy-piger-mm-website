function [beta] = gen_beta(Y, X, h, mu, V)

     % Parameters for Normal distribution describing conditional posterior distribution for slope parameters -> Normal(mubar,Vbar)

     Vbar = h*(X'*X)+inv(V);
     mubar =  inv(Vbar)*(h*(X'*Y)+inv(V)*mu);
     
     beta = mvnrnd(mubar,inv(Vbar));
     beta=beta';
     
end

