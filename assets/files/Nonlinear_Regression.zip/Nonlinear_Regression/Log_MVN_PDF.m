function [log_pdf_val] = Log_MVN_PDF(theta_in, mu_in, V_in)
    
    %Compute log of kernal of mvn pdf 
    log_pdf_val = -0.5*((theta_in-mu_in)'/V_in)*(theta_in-mu_in); 
         
end

