function [log_pdf_val] = Log_GAMMA_PDF(h_in, alpha_in, beta_in)
    
    %Compute log of kernal of gamma pdf 
    log_pdf_val = (alpha_in-1)*log(h_in) - (h_in/beta_in); 
         
end

