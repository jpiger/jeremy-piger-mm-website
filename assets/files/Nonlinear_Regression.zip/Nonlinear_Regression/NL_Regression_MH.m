%Bayesian estimation of a nonlinear regression model

clear;
clc;

[num,txt,raw] = xlsread('nonlin_regression_data.xlsx','Sheet1','A2:C101');

Y = num(:,1);
X1 = num(:,2);
X2 = num(:,3);

[N] = size(Y,1);

%=================  PRIOR PARAMETERS ====================

% hyperparameters for Normal distribution describing prior for conditional mean parameters 
%-> N(mu,V)

k = 3;  %Number of conditional mean parameters

mu = zeros(k,1);
V = eye(k)*10;

% hyperparameters for Gamma distribution describing prior for error precision, h = 1/sig2 -> Gamma(m,v)
% In this paramterization of Gamma, E(h) = m and Var(h) = 2*(m^2)/v

m = 1;
v = 3;

% Convert to the specification of Gamma used by Matlab
alpha=v/2;
beta = m/alpha;

%===== NUMBER OF SIMULATIONS FROM THE MH SAMPLER ===========

G0 = 10000;       %NUMBER OF BURN IN DRAWS
G = 20000;       %NUMBER OF POST CONVERGENCE DRAWS

total_draws = G0+G;  %TOTAL NUMBER OF DRAWS

%===== CALIBRATION OF PROPOSAL ===========

%Maximize the likelihood function to obtain the asymptotic covariance
%matrix for thetahat

theta_in = [1;1;1;1];

% Define a handle to reference log likelihood function

log_lik_handle = @(theta_in) Log_LF_NL_Regression_MLE(Y,X1,X2,theta_in);

% Call numerical optimizer

[theta_mle, fval] = fminsearch(log_lik_handle, theta_in);

% Compute Hessian matrix of negative of log likelihood function. 

[hess,err] = hessian(log_lik_handle,theta_mle);

cov = inv(hess);

% Standard errors for MLE 
std_errors =sqrt(diag(cov)); 

num_param = k+1;
mu_prop = zeros(num_param,1);
tau = 1; %Scaling for variance covariance matrix of shock to random walk proposal
R = tau.*cov;  % Variance covariance matrix of shock to random walk proposal

%========INITIAL VALUES FOR THE MH SAMPLER ===========

theta_g = theta_mle;

%===== STORAGE SPACES===========================

hmm = zeros(1,G);
gammamm = zeros(k,G);

accept=0;

%=================START SAMPLING================

itr=1;
while itr <= total_draws;  

theta_star = theta_g + (mvnrnd(mu_prop,R))';

log_lik_theta_star = Log_LF_NL_Regression(Y, X1, X2, theta_star);
log_lik_theta_g = Log_LF_NL_Regression(Y, X1, X2, theta_g);

log_prior_theta_star = Log_MVN_PDF(theta_star(2:k+1),mu,V) + Log_GAMMA_PDF(theta_star(1),alpha,beta);

log_prior_theta_g = Log_MVN_PDF(theta_g(2:k+1),mu,V) + Log_GAMMA_PDF(theta_g(1),alpha,beta);

% This acceptance probabilty does not include proposal, since they cancel
% out when using a random walk proposal density

log_acceptance_prob = (log_lik_theta_star+log_prior_theta_star)-(log_lik_theta_g+log_prior_theta_g);

acceptance_prob = exp(log_acceptance_prob);

acceptance_prob = min(acceptance_prob,1);

u=unifrnd(0,1);

if u<=acceptance_prob
    theta_g1 = theta_star;
    accept = accept+1;
else
    theta_g1 = theta_g;
end

% Print out acceptance rate every 1000th iteration
if mod(itr,1000)==0
disp(itr);
disp('Acceptance Rate: '); 
disp(accept/itr);
end
      
if itr>G0
    
    h_g1 = theta_g1(1);
    gamma_g1 = theta_g1(2:num_param);
    
    hmm(1,itr-G0) = h_g1;
    gammamm(:,itr-G0) = gamma_g1;

end

theta_g = theta_g1;

itr=itr+1;
end

disp('Maximum Likelihood Estimates and Standard Errors (first estimate is for precision):');
disp([theta_mle std_errors]);

disp('Posterior median of gamma parameters')
disp(median(gammamm'))

disp('Posterior median of disturbance variance')
disp(median(1./(hmm')))

figure;

ksdensity(gammamm(1,:)')
title('Gamma 1')

figure;

ksdensity(gammamm(2,:))
title('Gamma 2')

figure;

ksdensity(gammamm(3,:))
title('Gamma 3')