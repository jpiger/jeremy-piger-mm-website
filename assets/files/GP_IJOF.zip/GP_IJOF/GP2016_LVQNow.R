## R script implementing the LVQ nowcasts of Giusto and Piger (IJOF, 2016) 
## Authors: Andrea Giusto and Jeremy Piger
## Contact: andrea.giusto@dal.ca
## This version: 04/30/2016
##     This program assumes that the input data is stored in a directory called
##     "data" and that there exists a directory named "output" to store the 
##     nowcasts. The output is a csv table containing in each entry the share
##     of boostrapping replications that have produced a recessionary signal. 
library(kohonen)

## Control parameters:
NN <- 1
# NN controls the number of nearest neighbors to be used for classification 
# once the LVQ classifier has been trained.
VOTETH <- 1.0
# VOTETH controls the "vote threshold": it is used to require more than
# 50% majority to call a 1. A VOTETH = 1.0 implies that all the NN 
# nearest neighbors must agree that output should be 1 before signalling a 
# recession month. Values below 0.5 have no impact on the program.
set.seed(20)
# Seed for the random number generator.
N_BOOT<- 100
# Number of bootstrap iterations.

## Data intake:
# The input data must be stored in a subfolder named "data"
# The input data is assumed to have the following format:
#     * First column: Observation date (YYYYMM)
#     * Header: Vintage date (YYYYMM).
#     * Classification as 1 (NBER recession) or 0 for the in-sample period
#     * Out-of-sample period: value 2.
ind_prod <- read.table("data/ind_prod.csv", 
                        sep = ",", 
                        row.names = 1, 
                        header = TRUE)
man_trade_sale <- read.table("data/man_trade_sale.csv", 
                              sep = ",", 
                              row.names = 1, 
                              header = TRUE)
payroll_emp <- read.table("data/payroll_emp.csv", 
                          sep = ",", 
                          row.names = 1, 
                          header = TRUE)
pers_inc <- read.table("data/pers_inc.csv", 
                        sep = ",", 
                        row.names = 1, 
                        header = TRUE)
# The classification data is assumed to have the following format.
#     * First column: Observation date (YYYYMM).
#     * Header: Vintage date (YYYYMM).
#     * Classification as 0 or 1 for the in-sample period
#     * Classification as 2 for out-of-sample period.
#     * NAs wherever the analysis is not to be conducted due to missing vintage data
nber <- read.table("data/nber_dates_rt_variable.csv", 
                  sep = ",", 
                  row.names = 1, 
                  header = TRUE)
vintages <- as.list(colnames(ind_prod))
# The container object for the final classifier responses is "nowcasts"
nowcasts <- matrix(NA,nrow=dim(ind_prod)[1],ncol=dim(ind_prod)[2])
rownames(nowcasts) <- rownames(ind_prod)

## Loop over vintages:
for(i in 1:length(vintages)){
  ## Collect and organize current vintage data:
  cur <- vintages[[i]]
  this.vintage   <- as.matrix( cbind( ind_prod[, cur],
                                      man_trade_sale[, cur], 
                                      payroll_emp[, cur],
                                      pers_inc[, cur]) )
  cur.class.data <- as.matrix(nber[, cur])
  # The current input to the classifier consists of the four current 
  # observations plus the four lag-one observations
  nrows <- dim(this.vintage)[1]
  cur.data <- cbind(this.vintage[1:(nrows-1), ], this.vintage[2:nrows, ])
  # For consistency with the naming convention of the rows it is necessary 
  # to add an extra row of NAs
  cur.data <- rbind(c(NA,NA,NA,NA,NA,NA,NA,NA), cur.data)
  colnames(cur.data) <- c("ind_prod -1",
                          "man_trad_sale -1",
                          "payroll_emp -1",
                          "pers_inc -1",
                          "ind_prod 0" ,
                          "man_trad_sale 0",
                          "payroll_emp 0" ,
                          "pers_inc 0")
  # Due to the asynchronous release of the four data series, there are, at the 
  # end of each vintage, incomplete entries in "cur.data" 
  # Here we exploit the fact that if "pers_inc -1" is missing then every other 
  # entry in that row should be too.
  id.row <- is.na(cur.data[, "ind_prod -1"])
  cur.data[id.row, ] <- NA
  
  rm(this.vintage) # won't be needed anymore
  cbvDim <- 8 # dimensionality of the codebook vectors
  
  rownames(cur.data) <- rownames(ind_prod)
  rownames(cur.class.data) <- rownames(ind_prod)
  colnames(cur.class.data) <- "nber 0"


  ## Determine the in- and out-of-sample indeces:
  not.nas       <- !is.na(cur.data[, "man_trad_sale 0"]) &
                   !is.na(cur.data[, cbvDim]) & 
                   (!is.na(cur.class.data) & cur.class.data != 2)
  tot.not.nas   <- sum(not.nas)
  first         <- which(not.nas == TRUE)[1]
  last.train    <- first + tot.not.nas - 1
  train         <- seq(first, last.train)
  out.of.sample <- which(cur.class.data == 2)
  os.size       <- length(out.of.sample)
  # We assume that once called a recession will last at least 6 months. As 
  # a consequence, some months don't have a genuine nowcasting problem. 
  # Nonetheless we let the classifier produce an output response.
  if(os.size < 2){
    out.of.sample[1] <- last.train + 1
    out.of.sample[2] <- last.train + 2
    os.size          <- 2
  }
  rm(list=c("not.nas","tot.not.nas","first","last.train"))

  ## Standardization of the data:
  series.means <- apply(cur.data[train, ], 2, mean, na.rm=TRUE)
  series.sd    <- apply(cur.data[train, ], 2, sd, na.rm=TRUE)
  for(k in 1:cbvDim)
    cur.data[,k] <- (cur.data[, k] - series.means[k])/series.sd[k]

  ## Determine the number of CBVs:
  tot.rec.episodes <- dim(cur.data[train,][cur.class.data[train]==1,])[1]
  rec.data <- cur.data[train,][cur.class.data[train]==1,]

  ## Initializing temporary and permanent results containers:
  temp.cont <- array(0, dim = length(c(train, out.of.sample)))
  nowcasts[train, i] <- 0
  nowcasts[out.of.sample, i] <- 0

  ## Bootstrap loop (nowcasts here):
  for(j in 1:N_BOOT){
    temp.rec.data <- cur.data[train, ][cur.class.data[train] == 1,]
    temp.exp.data <- cur.data[train, ][cur.class.data[train] == 0,]
    # Expansion's data is always more plentiful than recessions' so 
    # "temp.exp.data" is randomly sampled to initialize a set of 
    # expansionary codebook vectors equal in number to that of the 
    # recession codebooks.
    idx <- sample(1:dim(temp.exp.data)[1], tot.rec.episodes)
    cbv0 <- list( x = rbind(temp.exp.data[idx,], temp.rec.data),
                  cl = as.factor(c(rep("0", tot.rec.episodes), 
                                   rep("1", tot.rec.episodes))) )
    cbv1 <- olvq1( cur.data[train,],as.factor(cur.class.data[train]), cbv0 )
    # The object "cbv0" contains the full set of initial codebooks stacked 
    # vertically with the expansions above and the recessions below. The 
    # object "cbv1" contains the final locations of the codebook vectors
    # after LVQ training.
    
    # "isf" is mnemonic of In-Sample-Forecasts and it is a container to store 
    # the K-Nearest Neighbors output. The function knn returns the number of 
    # codebooks with classification equal to 1 as an attribute of the output, 
    # so is it necessary to check that this attribute is greater or equal than 
    # the parameter VOTETH to ensure that the proper majority rule is enforced.
    isf <- knn(cbv1$x, cur.data[train, ], cbv1$cl, k = NN, prob = TRUE)
    temp.cont <- as.numeric(isf == 1 &
                            attributes(isf)$prob >= VOTETH)
    rm(isf) 
    
    # The following conditional statement produces the Out-of-Sample Forecast 
    # except for the last two dates, that require special treatment due to 
    # missing data
    if(os.size > 2){
      osf <- knn(cbv1$x, cur.data[out.of.sample[1:(os.size-2)], ], cbv1$cl, 
                 k = NN, prob = TRUE)
      temp.cont <- c( temp.cont,
                      as.numeric(osf==1 & attributes(osf)$prob >= VOTETH) )
      rm(osf) 
    }
    # Now the program deals with the FIRST missing data point caused by the 
    # data release timing. 
    # Start by making a copy of the codebook vector...
    truncated.cbv1 <- cbv1
    # ...then strip the missing manufactoring, and trade sales column
    truncated.cbv1$x <- cbv1[["x"]][,
                        -which(colnames(cur.data) == "man_trad_sale 0")]
    # do the same to the data to be classified
    data.point.without.missing <- cur.data[out.of.sample[os.size-1],
                                           -which(colnames(cur.data) == "man_trad_sale 0")]
    # perform the reduced-dimensionality nowcast
    rdn <- knn(truncated.cbv1$x, data.point.without.missing, cbv1$cl, 
              k=NN, prob=TRUE)
    rdn <- as.numeric(rdn==1 & attributes(rdn)$prob >= VOTETH)
    temp.cont <- c(temp.cont, rdn)
    rm(rdn, truncated.cbv1, data.point.without.missing)
    # Same process, for the last available observation, with three missing data 
    # columns.
    # Again, start by making a copy of the full codebook vector.
    truncated.cbv1 <- cbv1
    truncated.cbv1$x <- cbv1[["x"]][ ,c(-which(colnames(cur.data)=="man_trad_sale 0"), 
                                        -which(colnames(cur.data)=="pers_inc 0"),
                                        -which(colnames(cur.data)=="ind_prod 0")) ]
    truncated.cbv1$x <- truncated.cbv1[["x"]][ ,-which(colnames(cur.data)=="man_trad_sale -1")]
    # repeat on the data to be classified
    data.point.without.missing <- cur.data[ out.of.sample[os.size], c(-which(colnames(cur.data)=="man_trad_sale 0"),
                                                                      -which(colnames(cur.data)=="pers_inc 0"),
                                                                      -which(colnames(cur.data)=="ind_prod 0")) ]
    data.point.without.missing <- data.point.without.missing[-which(colnames(cur.data)=="man_trad_sale -1")]
    # perform the reduced-dimensionality nowcast
    rdn <- knn(truncated.cbv1$x, data.point.without.missing, cbv1$cl, 
               k = NN, prob = TRUE)
    temp.cont <- c(temp.cont, as.numeric(rdn==1 & attributes(rdn)$prob>=VOTETH))
    rm(rdn)
    # finalizing, and restoring the necessary conditions for the next iteration 
    nowcasts[!is.na(nowcasts[,i]),i] <- nowcasts[!is.na(nowcasts[,i]),i] + 
                                                  temp.cont
    temp.cont <- 0
   }
   nowcasts[,i] <- nowcasts[,i]/N_BOOT
   print(vintages[[i]]) # check progress
}

## Writing the output to file.
now <- date()
filename <- paste("output/",now,".csv",sep="")
write.table(nowcasts,file=filename,sep=",",append=TRUE)






