function [log_lik_val] = Log_LF_NL_Regression(Y, X1, X2, theta_in)

    [N,c] = size(Y);
    
    [num_param,c] = size(theta_in);

    h_in = theta_in(1);
    gamma_in = theta_in(2:num_param);

    resid = Y - (gamma_in(1).*(X1.^gamma_in(3)) + gamma_in(2).*(X2.^gamma_in(3))).^(1/gamma_in(3));

    log_lik_val = -(N/2)*log(2*pi) + (N/2)*log(h_in) -(h_in/2)*(resid'*resid); 
         
end

