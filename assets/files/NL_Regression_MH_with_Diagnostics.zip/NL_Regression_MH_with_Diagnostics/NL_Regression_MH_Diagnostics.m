%% Bayesian estimation of a nonlinear regression model

% Includes estimation of marginal likelihood using approach of 
% Chib and Jeliaskov (1995) as well as Modified Harmonic Mean as in Geweke
% (1999).

%% Load Data

clear;
clc;

[num,txt,raw] = xlsread('nonlin_regression_data.xlsx','Sheet1','A2:C101');

Y = num(:,1);
X1 = num(:,2);
X2 = num(:,3);

[N] = size(Y,1);

%% Bayesian Estimation via Metropolis-Hastings Algorithm

% Prior Parameters

% Hyperparameters for Normal distribution describing prior for conditional mean parameters 
%-> N(mu,V)

k = 3;  %Number of conditional mean parameters

mu = zeros(k,1);
V = eye(k)*10;
chol_V = chol(V)';

% Hyperparameters for Gamma distribution describing prior for error precision, h = 1/sig2 -> Gamma(m,v)
% In this parameterization of Gamma, E(h) = m and Var(h) = 2*(m^2)/v

m = 1;
v = 3;

% Convert to the specification of Gamma used by Matlab

alpha=v/2;
beta = m/alpha;

% Number of Simulations from the MH Sampler

G0 = 100000;       %Number of burn-in draws
G = 1000000;       %Number of post-convergence draws

total_draws = G0+G;  %Total number of draws

% Calibration of Proposal

cov_prop = eye(4);
num_param = k+1;
mu_prop = zeros(num_param,1);
tau = 0.001;  %Scaling for variance covariance matrix of shock to random walk proposal
R = tau.*cov_prop;  % Variance covariance matrix of shock to random walk proposal
chol_R = chol(R)';

% Initital Values for the MH Sampler

theta_g = ones(num_param,1);
log_lik_theta_g = Log_LF_NL_Regression(Y, X1, X2, theta_g);
log_prior_theta_g_kernel = Log_MVN_pdf_kernel(theta_g(2:k+1),mu,chol_V) + Log_Gamma_pdf_kernel(theta_g(1),alpha,beta);

% Storage Spaces

hmm = zeros(1,G);
gammamm = zeros(k,G);

h0mm = zeros(1,G0);
gamma0mm = zeros(k,G0);

accept=0;

% Start Sampling

itr=1;
while itr <= total_draws;  
    
    theta_star = theta_g + (mvnrnd(mu_prop,R))';

    log_lik_theta_star = Log_LF_NL_Regression(Y, X1, X2, theta_star);

    log_prior_theta_star_kernel = Log_MVN_pdf_kernel(theta_star(2:k+1),mu,chol_V) + Log_Gamma_pdf_kernel(theta_star(1),alpha,beta);

    % This acceptance probabilty does not include proposal, since they cancel
    % out when using a random walk proposal density

    log_acceptance_prob = (log_lik_theta_star+log_prior_theta_star_kernel)-(log_lik_theta_g+log_prior_theta_g_kernel);
    acceptance_prob = exp(log_acceptance_prob);
    acceptance_prob = min(acceptance_prob,1);

    u=unifrnd(0,1);

    if u<=acceptance_prob;
        theta_g = theta_star;
        log_lik_theta_g = log_lik_theta_star;
        log_prior_theta_g_kernel = log_prior_theta_star_kernel;
        accept = accept+1;
    end;
      
    if itr>G0;
        hmm(1,itr-G0) = theta_g(1);
        gammamm(:,itr-G0) = theta_g(2:num_param);
    else
        h0mm(1,itr) = theta_g(1);
        gamma0mm(:,itr) = theta_g(2:num_param);
    end;

    % Print out progress indicator and acceptance rate
    if mod(itr/total_draws,0.10)==0;
        clc;
        disp('Estimation via Metropolis-Hastings Sampler. Please Wait...');
        disp('Percent Complete');
        disp(((itr*100)/total_draws));
        disp('Acceptance Rate: '); 
        disp(accept/itr);
    end;
    
    itr=itr+1;
end;

%% Display Results

disp('Posterior median of gamma parameters')
disp(median(gammamm'));

disp('Posterior median of disturbance variance')
disp(median(1./(hmm')));

figure(1);
subplot(2,2,1);
ksdensity(gammamm(1,:)')
title('Gamma 1')

subplot(2,2,2);
ksdensity(gammamm(2,:))
title('Gamma 2')

subplot(2,2,3);
ksdensity(gammamm(3,:))
title('Gamma 3')

subplot(2,2,4);
ksdensity(hmm(1,:))
title('Precision')


%% Compute and Report MCMC Diagnostics

% Trace plot for all parameters

num_period = G0;

figure(2);
subplot(2,2,1);
plot(1:num_period, gamma0mm(1,1:num_period));
title('Trace plot for gamma1');

subplot(2,2,2);
plot(1:num_period, gamma0mm(2,1:num_period));
title('Trace plot for gamma2');

subplot(2,2,3);
plot(1:num_period, gamma0mm(3,1:num_period));
title('Trace plot for gamma3');

subplot(2,2,4);
plot(1:num_period, h0mm(1,1:num_period));
title('Trace plot for precision');

% Running mean plot

theta0mm = [gamma0mm;h0mm];

running_mean_vec = zeros(k+1,G0);
running_mean_vec(:,1) = theta0mm(:,1);

itr=2;
while itr <= G0;
    
    mean_vec = mean(theta0mm(:,1:itr)');
    
    running_mean_vec(:,itr) = mean_vec';
    
    itr=itr+1;

end;

num_period = G0;

figure(3)
subplot(2,2,1)
plot(1:num_period, running_mean_vec(1,1:num_period))
title('Running mean plot for gamma1')

subplot(2,2,2);
plot(1:num_period, running_mean_vec(2,1:num_period))
title('Running mean plot for gamma2')

subplot(2,2,3);
plot(1:num_period, running_mean_vec(3,1:num_period))
title('Running mean plot for gamma3')

subplot(2,2,4);
plot(1:num_period, running_mean_vec(4,1:num_period))
title('Running mean plot for precision')

%Autocorrelation Function for part of pre-convergence period

num_ac = 1000;
acf_vec = zeros(num_ac,1);

itr=1;
while itr <= num_ac;
    
    gamma3fmm = gamma0mm(3,1+itr:G0);
    gamma3lmm = gamma0mm(3,1:G0-itr);
    
    q=cov(gamma3fmm',gamma3lmm');
    acf=corrcov(q);
    
    acf_vec(itr) = acf(1,2);
    
    itr=itr+1;

end;

figure(4)
bar(1:num_ac, acf_vec)
title('Autocorrelation function (pre-convergence) for gamma3 parameter')

% Effective sample size for coefficient on gamma1

num_ac = 1000;
acf_sum = 0;

itr=1;
while itr <= num_ac;
        
    gamma3fmm = gammamm(3,1+itr:G);
    gamma3lmm = gammamm(3,1:G-itr);
    
    q=cov(gamma3fmm',gamma3lmm');
    acf=corrcov(q);
    
    acf_sum = acf_sum + acf(1,2);
    
    itr=itr+1;

end;

ESS = G/(1+2*acf_sum);

disp('The Effective Sample Size for the gamma3 parameter is:');
disp(round(ESS));