%Bayesian estimation of a linear regression model using data from
%Hamermesh and Parker (2005, Economics of Education Review)
%Estimation conducted using Gibbs Sampler

clear;
clc;

tic;

[num,txt,raw] = xlsread('TeachingRatings.xls',1);

minority = num(:,1);
age = num(:,2);
female = num(:,3);
one_credit = num(:,4);
beauty = num(:,5);
course_eval = num(:,6);
intro = num(:,7);
nnenglish = num(:,8);

Y = course_eval;

[N,c] = size(Y); %N is the sample size

X = [ones(N,1) beauty female minority nnenglish intro age one_credit];


%=================  PRIOR PARAMETERS ====================

% hyperparameters for Normal distribution describing prior for conditional mean parameters 
%-> N(mu,V)

[r,k] = size(X);  %k is the number of conditional mean parameters

mu = zeros(k,1);
V = eye(k)*10;

% hyperparameters for Gamma distribution describing prior for error precision, h = 1/sig2 -> Gamma(m,v)
% In this paramterization of Gamma, E(h) = m and Var(h) = 2*(m^2)/v

m = 1;
v = 3;


%===== DESIGN  for THE GIBBS SAMPLER ===========

G0 = 5000;       %NUMBER OF BURN IN DRAWS
G = 10000;       %NUMBER OF POST CONVERGENCE DRAWS

total_draws = G0+G;  %TOTAL NUMBER OF DRAWS


%========INITIAL VALUES FOR THE GIBBS SAMPLER ===========

beta_g = zeros(k,1);


%===== STORAGE SPACES===========================

betamm = zeros(k,G);
hmm = zeros(1,G);

itr=1;
while itr <= total_draws;  

%=================START SAMPLING================

h_g=gen_h(Y,X,beta_g,N,m,v);

beta_g=gen_beta(Y,X,h_g,mu,V);


%=========STORE RESULTS==========================

if itr>G0;
     
betamm(:,itr-G0) = beta_g;
hmm(:,itr-G0) = h_g;

end;

itr=itr+1;
end;

disp('Posterior mean of intercept and slope parameters')
disp((mean(betamm'))')

disp('Posterior mean of disturbance variance')
disp(mean(1./(hmm')))

disp('OLS estimates of intercept and slope parameters')
disp(inv(X'*X)*X'*Y)

ksdensity(betamm(2,:))
title('Effect of Beauty on Course Evaluations')

toc;