function [beta] = gen_beta_scale(Y, X, h, mu, V)

     % Parameters for Normal distribution describing conditional posterior distribution for slope parameters -> Normal(mubar,Vbar)

     Sigma_inv = diag(h);

     Vbar = X'*Sigma_inv*X + inv(V);
     
     mubar = Vbar\((X'*Sigma_inv*Y))+ (V\mu);
     
     beta = mvnrnd(mubar,inv(Vbar));
     beta=beta';
     
end

