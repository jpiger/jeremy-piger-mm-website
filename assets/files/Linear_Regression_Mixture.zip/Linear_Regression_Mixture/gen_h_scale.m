function [h] = gen_h_scale(Y, X, beta, m, v)

     e_vec = Y - X*beta;

     % Parameters for Gamma distribution describing conditional posterior distribution for error precision h = 1/sig2 -> Gamma(mbar,vbar)

     vbar = 1 + v;
     mbar_vec = vbar*(1./(e_vec.^2 + v/m));
     
     % The following converts mbar and vbar into the definition of the gamma definition used by Matlab random number generator (gamrnd), Gamma(a,b). 
     % In this paramterization of Gamma, E(h) = a*b and Var(h) = a*b^2.  a is called the shape parameter and b the scale parameter.     

     a = vbar/2;
     b = mbar_vec./a;
     
     h = gamrnd(a,b); %h is a vector of independent draws from the N posterior distributions for h(i). 
    
end