%% Bayesian estimation of a linear regression model with a Scale Mixture
%  Normals for distribution of disturbance term
%  Estimation is done for simulated data, which is produced within the
%  program

%Estimation conducted using a Metropolis within Gibbs Sampler

%% Simulate Data Consistent with the Assumed DGP
clear;
clc;

N=200;

X=[ones(N,1), normrnd(0,sqrt(3),N,1)];

true_beta = [1;2];

true_m = 1;
true_v = 3;

alpha = true_v/2;
beta = true_m/alpha;

true_h = gamrnd(alpha,beta,N,1);
true_sig = sqrt(1./true_h);

u = normrnd(0,true_sig);

Y = X*true_beta + u;

%% Metropolis within Gibbs Sampler 

% Prior Parameters

% Hyperparameters for Normal distribution describing prior for conditional mean parameters 
%-> N(mu,V)

k = size(X,2);  % Number of conditional mean parameters

mu = zeros(k,1);
V = eye(k)*10;

% h is the vector of N precision parameters, with the ith element giving 
% the precision of the ith disturbance term, i=1,...,N. The prior for h 
% is a hierarchical prior:  h~Gamma(m,v)

% Hyperparameters for prior for m and v. m ~ exponential(a), v ~ exponential(b) 

a = 1;
b = 1;

% Design for the Metropolis-within-Gibbs sampler 

G0 = 10000;       % Number of burn-in draws
G = 100000;       % Number of post-convergence draws

total_draws = G0+G;  % Total number of draws

% Calibration of proposal for MH draws of m and v

num_param = 2;
mu_prop = zeros(num_param,1);
cov_p = eye(num_param);
tau = .01; 
R = eye(num_param).*tau;

% Initial values for the Sampler

beta_g = zeros(k,1);
m_g = 1;
v_g = 1;
theta_g = [m_g;v_g];

% Storage Spaces

betamm = zeros(k,G);
mmm = zeros(1,G);
vmm = zeros(1,G);

accept=0;

itr=1;
while itr <= total_draws;
    
    % Start Sampling

    % Gibbs draws of beta and h

    h_g = gen_h_scale(Y,X,beta_g,m_g,v_g);
    
    beta_g = gen_beta_scale(Y,X,h_g,mu,V);

    % MH draw of m and v

    theta_star = theta_g + (mvnrnd(mu_prop,R))';
    m_star = theta_star(1);
    v_star = theta_star(2);

    alpha = v_star/2;
    beta = m_star/alpha;
    
    log_lik_theta_star = sum(Log_Gamma_pdf(h_g,alpha,beta));
    
    alpha = v_g/2;
    beta = m_g/alpha;
    
    log_lik_theta_g = sum(Log_Gamma_pdf(h_g,alpha,beta));
    
    log_prior_theta_star = Log_Exponential_pdf(m_star,a) + Log_Exponential_pdf(v_star,b);
    log_prior_theta_g = Log_Exponential_pdf(m_g,a) + Log_Exponential_pdf(v_g,b);
   
    log_acceptance_prob = (log_lik_theta_star+log_prior_theta_star)-(log_lik_theta_g+log_prior_theta_g);

    acceptance_prob = exp(log_acceptance_prob);
    
    if (m_star<0 || v_star < 0);
        acceptance_prob=0;
    end;

    acceptance_prob = min(acceptance_prob,1);

    u = unifrnd(0,1);

    if u<=acceptance_prob;
        theta_g = theta_star;
        m_g = theta_g(1);
        v_g = theta_g(2);
        accept = accept+1;
    end;

    % Store results
    
    if itr > G0;
        betamm(:,itr-G0) = beta_g;
        mmm(itr-G0) = m_g;
        vmm(itr-G0) = v_g;
    end;

    % Print out progress indicator
    if mod(itr/total_draws,0.10)==0;
        clc;
        disp('Estimation via Metropolis-within-Gibbs Sampler. Please Wait...');
        disp('Percent Complete');
        disp(((itr*100)/total_draws));
        disp('Current Acceptance Rate for Metropolis Step is');
        disp(accept/itr);
    end;
      
itr=itr+1;
end;

%% Display Results
disp('Posterior median of intercept and slope parameters')
disp(median(betamm'));

disp('Posterior median of parameter of Gamma distribution for h (m and v)')
disp(median(mmm'));
disp(median(vmm'));

disp('OLS estimates of intercept and slope parameters')
disp((X'*X)\X'*Y);

figure(1);
subplot(2,2,1);
ksdensity(betamm(1,:)')
title('Intercept')

subplot(2,2,2);
ksdensity(betamm(2,:)')
title('Slope')

subplot(2,2,3);
ksdensity(mmm(1,:)')
title('m')

subplot(2,2,4);
ksdensity(vmm(1,:)')
title('v')