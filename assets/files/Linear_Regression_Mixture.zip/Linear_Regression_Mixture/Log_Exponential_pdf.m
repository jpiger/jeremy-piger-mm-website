function [log_pdf_val] = Log_Exponential_pdf(x_in, a_in)
    
    %Compute log of exponential pdf 
    log_pdf_val = (log(a_in) - a_in*x_in); 
         
end

