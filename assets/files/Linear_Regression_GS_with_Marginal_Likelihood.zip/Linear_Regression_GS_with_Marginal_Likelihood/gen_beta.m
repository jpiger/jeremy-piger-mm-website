function [beta] = gen_beta(Y, X, h, mu, V)

     % Parameters for Normal distribution describing conditional posterior distribution for slope parameters -> Normal(mubar,Vbar)

     Vbar = h*(X'*X)+inv(V);
     mubar =  Vbar\(h*(X'*Y)+ V\mu);
     
     beta = mvnrnd(mubar,inv(Vbar));
     beta=beta';
     
end

