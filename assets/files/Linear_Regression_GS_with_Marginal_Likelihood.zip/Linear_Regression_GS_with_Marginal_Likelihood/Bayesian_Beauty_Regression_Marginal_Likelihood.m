%% Bayesian estimation of a linear regression model via the Gibbs Sampler

% Uses data from Hamermesh and Parker (2005, Economics of Education Review)

% Marginal Likelihood estimated using approach of Chib (1995)

%% Load Data

clear;
clc;

[num,txt,raw] = xlsread('TeachingRatings.xls',1);

minority = num(:,1);
age = num(:,2);
female = num(:,3);
one_credit = num(:,4);
beauty = num(:,5);
course_eval = num(:,6);
intro = num(:,7);
nnenglish = num(:,8);

Y = course_eval;

[N,c]=size(Y);

X = [ones(N,1) beauty female minority nnenglish intro one_credit];

%% Gibbs Sampler 

% Prior Parameters

% hyperparameters for Normal distribution describing prior for conditional mean parameters 
%-> N(mu,V)

[N,k] = size(X);  %Sample size (N) and number of conditional mean parameters (k)

mu = zeros(k,1);
V = eye(k)*10;
inv_V = inv(V);
chol_V = chol(V);

% hyperparameters for Gamma distribution describing prior for error precision, h = 1/sig2 -> Gamma(m,v)
% In this paramterization of Gamma, E(h) = m and Var(h) = 2*(m^2)/v

m = 1;
v = 3;

% Convert to the specification of Gamma used by Matlab

a = v/2;
b = m/a;

% Design for the Gibbs Sampler

G0 = 100%00;       % Number of burn-in draws
G = 100%000;       % Number of post-convergence draws

total_draws = G0+G;  % Total number of draws

% Initial values for the Gibbs Sampler

beta_g = zeros(k,1);

% Storage Spaces

betamm = zeros(k,G);
hmm = zeros(1,G);

itr=1;
while itr <= total_draws;  
    
    % Start sampling
    
    h_g=gen_h(Y,X,beta_g,N,m,v);
    
    beta_g=gen_beta(Y,X,h_g,mu,V);
    
    % Store Results
    
    if itr>G0;
        betamm(:,itr-G0) = beta_g;
        hmm(itr-G0) = h_g;
    end;
    
    % Print out progress indicator
    if mod(itr/total_draws,0.10)==0;
        clc;
        disp('Estimation via Gibbs Sampling. Please Wait...');
        disp('Percent Complete');
        disp(((itr*100)/total_draws));
    end;
    
    itr=itr+1;
end;

disp('Posterior median of intercept and slope parameters')
disp(median(betamm')')

disp('Posterior median of disturbance variance')
disp(median(1./(hmm'))')

disp('OLS estimates of intercept and slope parameters')
disp(inv(X'*X)*X'*Y)

%% BEGIN COMPUTATION OF MARGINAL LIKELIHOOD USING APPROACH OF CHIB (1995)

% Compute posterior medians at which to compute basic marginal likelihood identity

beta_tilde = median(betamm')';
h_tilde = median(hmm');

% Evaluate likelihood function and prior at beta_tilde and h_tilde

resid = Y-X*beta_tilde;

lik_val = ((2*pi)^(-N/2))*h_tilde^(N/2)*exp((-h_tilde/2)*(resid'*resid));

prior_val_beta = exp(Log_MVN_pdf(beta_tilde,mu,chol_V));

prior_val_h = exp(Log_Gamma_pdf(h_tilde,a,b));

% Evaluate posterior at beta_tilde and h_tilde

% Compute p(beta_tilde/h_tilde,Y) analytically

Vbar = h_tilde*(X'*X)+inv(V);
mubar = Vbar\(h_tilde*(X'*Y)+V\mu);

post_val_beta = exp(Log_MVN_pdf(beta_tilde,mubar,chol(inv(Vbar))));

% Estimate p(h_tilde|Y) via Monte Carlo integration

post_val_h=0;

itr=1;
while itr <= G;
    
    resid = Y-X*(betamm(:,itr));
    
    vbar = N + v;
    mbar = vbar/(resid'*resid + v/m);

    abar = vbar/2;
    bbar = mbar/abar;
    
    post_val_h = post_val_h + exp(Log_Gamma_pdf(h_tilde,abar,bbar));
    
    if mod(itr/G,0.10)==0;
        clc;
        disp('Marginal Likelihood Calculating Using Chib (1995) Approach. Please Wait...');
        disp('Percent Complete');
        disp(((itr*100)/G));
    end;
    
    itr=itr+1;
    
end;

post_val_h = post_val_h/G;

prior_val = prior_val_beta*prior_val_h;
post_val = post_val_beta*post_val_h;

marg_lik_chib = (lik_val*prior_val)/post_val;

%% The following code estimates the marginal likelihood via direct Monte
% Carlo integration. This doesn't work well.  

num_sim_direct = 100000;
lik_val=0;

itr=1;
while itr <= num_sim_direct;
    
    beta_prior_gen = mvnrnd(mu,V)';
    
    h_prior_gen = gamrnd(a,b);
 
    resid = Y-X*beta_prior_gen;
    
    lik_val = lik_val + ((2*pi)^(-N/2))*h_prior_gen^(N/2)*exp((-h_prior_gen/2)*(resid'*resid));
    
    if mod(itr/num_sim_direct,0.10)==0;
        clc;
        disp('Marginal Likelihood Calculating Using Direct Monte Carlo Integration from the Prior. Please Wait...');
        disp('Percent Complete');
        disp(((itr*100)/num_sim_direct));
    end;
    
    itr=itr+1;
end;

marg_lik_direct = lik_val/num_sim_direct;

%% Display Results

clc;
disp('Marginal Likelihood and Log Marginal Likelihood Calculated using Chib (1995) approach: ');
disp(marg_lik_chib);
disp(log(marg_lik_chib));

disp('Marginal Likelihood and Log Marginal Likelihood Calculated using Direct Monte Carlo Integration from the Prior: ');
disp(marg_lik_direct);
disp(log(marg_lik_direct));